export type BotState =
  | 'IDLE'
  | 'WAITING_FOR_GAME'
  | 'PLAYING'
  | 'GAME_OVER'
  | 'RESULT_SCREEN'
  | 'ADVERTISEMENT'
  | 'WAITING_FOR_CLOSE'
  | 'STARTING_NEW_GAME'
  | 'STOPPED'
  | 'ERROR';

export type BotSpeed = 'slow' | 'normal' | 'fast';

export type SwipeStyle = 'blade_linear' | 'multi_slice_curve' | 'smart_bezier';

export type DetectionEngineType = 'hybrid_cv_color' | 'tflite_custom' | 'gemini_vision_assisted';

export interface Point2D {
  x: number; // normalized 0..1
  y: number; // normalized 0..1
}

export interface DetectedItem {
  id: string;
  type: 'fruit' | 'bomb';
  name: string;
  color: string;
  x: number; // normalized center X (0..1)
  y: number; // normalized center Y (0..1)
  radius: number; // normalized radius
  confidence: number; // 0..1
  velocityX?: number;
  velocityY?: number;
  isSliced?: boolean;
  priority?: number;
}

export interface SwipePath {
  id: string;
  points: Point2D[];
  targetFruitIds: string[];
  avoidsBombIds: string[];
  safetyScore: number; // 0..100
  durationMs: number;
  timestamp: number;
  isBombCollisionRisk: boolean;
}

export interface BotSettings {
  swipeSpeed: BotSpeed;
  detectionIntervalMs: number;
  fruitConfidenceThreshold: number;
  bombConfidenceThreshold: number;
  bombSafetyRadius: number; // normalized e.g. 0.15
  restartDelayMs: number;
  adTimeoutSeconds: number;
  maxGames: number; // 0 = unlimited
  sessionTimeoutMinutes: number; // 0 = unlimited
  autoRestart: boolean;
  showFloatingOverlay: boolean;
  debugMode: boolean;
  swipeStyle: SwipeStyle;
  detectionEngine: DetectionEngineType;
  enableSoundEffects: boolean;
  vibrateOnBombWarning: boolean;
}

export interface PermissionStatus {
  accessibilityService: 'granted' | 'denied' | 'prompt';
  screenCapture: 'granted' | 'denied' | 'prompt';
  overlayPermission: 'granted' | 'denied' | 'prompt';
}

export interface BotMetrics {
  gamesPlayed: number;
  sessionStartTime: number | null;
  fruitsSliced: number;
  bombsAvoided: number;
  adsDismissed: number;
  gesturesExecuted: number;
  avgReactionTimeMs: number;
  currentCombo: number;
  maxCombo: number;
  fps: number;
  lastDetectedButton: string | null;
  lastGestureSummary: string | null;
  currentErrorMessage: string | null;
}

export interface LogEntry {
  id: string;
  timestamp: number;
  level: 'info' | 'gesture' | 'vision' | 'ad' | 'warn' | 'error';
  message: string;
  details?: Record<string, unknown>;
}

export interface AccessibleButtonCandidate {
  id: string;
  text: string;
  viewId?: string;
  bounds: { x: number; y: number; width: number; height: number };
  clickable: boolean;
  type: 'play' | 'replay' | 'continue' | 'next' | 'close' | 'skip' | 'other';
  confidence: number;
}
