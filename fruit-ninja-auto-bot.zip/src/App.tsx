import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { VisionRadarView } from './components/VisionRadarView';
import { CalibrationWorkbench } from './components/CalibrationWorkbench';
import { FloatingOverlaySimulator } from './components/FloatingOverlaySimulator';
import { NativeSourceExplorer } from './components/NativeSourceExplorer';
import { SettingsModal } from './components/SettingsModal';
import { LogsPanel } from './components/LogsPanel';
import {
  BotState,
  BotSettings,
  BotMetrics,
  PermissionStatus,
  LogEntry,
  SwipePath,
  AccessibleButtonCandidate,
} from './types';
import { ninjaAudio } from './services/AudioService';

const DEFAULT_SETTINGS: BotSettings = {
  swipeSpeed: 'normal',
  detectionIntervalMs: 50,
  fruitConfidenceThreshold: 0.65,
  bombConfidenceThreshold: 0.75,
  bombSafetyRadius: 0.16,
  restartDelayMs: 1500,
  adTimeoutSeconds: 15,
  maxGames: 0, // 0 = unlimited
  sessionTimeoutMinutes: 0, // 0 = unlimited
  autoRestart: true,
  showFloatingOverlay: true,
  debugMode: true,
  swipeStyle: 'smart_bezier',
  detectionEngine: 'hybrid_cv_color',
  enableSoundEffects: true,
  vibrateOnBombWarning: true,
};

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [botState, setBotState] = useState<BotState>('IDLE');
  const [settings, setSettings] = useState<BotSettings>(DEFAULT_SETTINGS);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const [permissions, setPermissions] = useState<PermissionStatus>({
    accessibilityService: 'granted',
    screenCapture: 'granted',
    overlayPermission: 'granted',
  });

  const [metrics, setMetrics] = useState<BotMetrics>({
    gamesPlayed: 14,
    sessionStartTime: Date.now() - 1000 * 60 * 18, // 18 mins ago
    fruitsSliced: 284,
    bombsAvoided: 62,
    adsDismissed: 3,
    gesturesExecuted: 198,
    avgReactionTimeMs: 42,
    currentCombo: 3,
    maxCombo: 9,
    fps: 60,
    lastDetectedButton: 'Replay',
    lastGestureSummary: 'Swipe [3 targets, 90% safety]',
    currentErrorMessage: null,
  });

  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: 'log_1',
      timestamp: Date.now() - 120000,
      level: 'info',
      message: 'FruitNinjaAccessibilityService connected (1080x2400 resolution)',
    },
    {
      id: 'log_2',
      timestamp: Date.now() - 95000,
      level: 'vision',
      message: 'MediaProjection active: RGBA_8888 frame capture 60 FPS',
    },
    {
      id: 'log_3',
      timestamp: Date.now() - 70000,
      level: 'gesture',
      message: 'Dispatched Bezier curve: Watermelon + Banana [Safety 94%]',
    },
    {
      id: 'log_4',
      timestamp: Date.now() - 45000,
      level: 'ad',
      message: 'Ad detected (Unity Ads). Scanned Skip button in 5.2s',
    },
  ]);

  const addLog = (
    level: LogEntry['level'],
    message: string,
    details?: Record<string, unknown>
  ) => {
    const newEntry: LogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      level,
      message,
      details,
    };
    setLogs((prev) => [newEntry, ...prev.slice(0, 150)]);
  };

  const handleUpdateSettings = (newSettings: Partial<BotSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    addLog('info', 'Updated Bot Settings', newSettings);
  };

  const handleStartBot = () => {
    if (permissions.accessibilityService !== 'granted') {
      alert('Please enable the AccessibilityService permission in the Dashboard before starting.');
      return;
    }
    setBotState('WAITING_FOR_GAME');
    addLog('info', 'Bot Started: Waiting for Fruit Ninja window focus');

    setTimeout(() => {
      setBotState('PLAYING');
      addLog('info', 'Fruit Ninja detected in foreground. Beginning continuous CV swipe loop.');
    }, 1200);
  };

  const handleStopBot = () => {
    setBotState('STOPPED');
    addLog('info', 'Bot stopped by user. All active swiping paused.');
  };

  const handleEmergencyStop = () => {
    setBotState('STOPPED');
    ninjaAudio.playEmergencyStop();
    addLog('error', 'EMERGENCY STOP TRIGGERED: Cancelled all pending gestures immediately.');
  };

  const handleToggleBot = () => {
    if (botState === 'PLAYING' || botState === 'WAITING_FOR_GAME') {
      handleStopBot();
    } else {
      handleStartBot();
    }
  };

  const handleGrantPermission = (perm: keyof PermissionStatus) => {
    setPermissions((prev) => ({ ...prev, [perm]: 'granted' }));
    ninjaAudio.playButtonClick();
    addLog('info', `Granted Android Permission: ${perm}`);
  };

  const handleSliceFruit = (count: number) => {
    setMetrics((prev) => {
      const nextCombo = prev.currentCombo + count;
      return {
        ...prev,
        fruitsSliced: prev.fruitsSliced + count,
        currentCombo: nextCombo,
        maxCombo: Math.max(prev.maxCombo, nextCombo),
      };
    });
  };

  const handleAvoidBomb = () => {
    setMetrics((prev) => ({
      ...prev,
      bombsAvoided: prev.bombsAvoided + 1,
    }));
  };

  const handleRecordGesture = (swipe: SwipePath) => {
    setMetrics((prev) => ({
      ...prev,
      gesturesExecuted: prev.gesturesExecuted + 1,
      lastGestureSummary: `Path (${swipe.targetFruitIds.length} fruits, ${swipe.safetyScore}% safe)`,
    }));
    addLog('gesture', `Dispatched swipe gesture: ${swipe.targetFruitIds.length} target(s)`, {
      pointsCount: swipe.points.length,
      safetyScore: swipe.safetyScore,
      durationMs: swipe.durationMs,
    });
  };

  const handleSimulateButtonClick = (btn: AccessibleButtonCandidate) => {
    setMetrics((prev) => ({
      ...prev,
      lastDetectedButton: btn.text,
    }));
    addLog('info', `AccessibilityNodeInfo clicked: "${btn.text}" (${btn.type})`, {
      confidence: btn.confidence,
    });

    if (btn.type === 'replay' || btn.type === 'play' || btn.type === 'continue') {
      setBotState('STARTING_NEW_GAME');
      setTimeout(() => {
        setBotState('PLAYING');
        setMetrics((prev) => ({ ...prev, gamesPlayed: prev.gamesPlayed + 1, currentCombo: 0 }));
        addLog('info', 'Started new game! Incremented Games Played.');
      }, 1000);
    } else if (btn.type === 'skip' || btn.type === 'close') {
      setMetrics((prev) => ({ ...prev, adsDismissed: prev.adsDismissed + 1 }));
      setBotState('WAITING_FOR_GAME');
      setTimeout(() => {
        setBotState('PLAYING');
      }, 800);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0b0e] text-[#f0f2f5] flex flex-col selection:bg-orange-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        botState={botState}
        onEmergencyStop={handleEmergencyStop}
        isMuted={isMuted}
        onToggleMute={() => {
          const next = !isMuted;
          setIsMuted(next);
          ninjaAudio.setMuted(next);
        }}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        overlayActive={settings.showFloatingOverlay}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {activeTab === 'dashboard' && (
          <Dashboard
            botState={botState}
            settings={settings}
            metrics={metrics}
            permissions={permissions}
            onStartBot={handleStartBot}
            onStopBot={handleStopBot}
            onEmergencyStop={handleEmergencyStop}
            onUpdateSettings={handleUpdateSettings}
            onGrantPermission={handleGrantPermission}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'vision' && (
          <VisionRadarView
            botState={botState}
            settings={settings}
            onSliceFruit={handleSliceFruit}
            onAvoidBomb={handleAvoidBomb}
            onRecordGesture={handleRecordGesture}
          />
        )}

        {activeTab === 'calibration' && (
          <CalibrationWorkbench
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onSimulateButtonClick={handleSimulateButtonClick}
          />
        )}

        {activeTab === 'overlay' && (
          <FloatingOverlaySimulator
            botState={botState}
            metrics={metrics}
            onToggleBot={handleToggleBot}
            onEmergencyStop={handleEmergencyStop}
          />
        )}

        {activeTab === 'native' && <NativeSourceExplorer />}

        {activeTab === 'logs' && (
          <LogsPanel logs={logs} onClearLogs={() => setLogs([])} />
        )}

        {activeTab === 'settings' && (
          <SettingsModal
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onResetDefaults={() => setSettings(DEFAULT_SETTINGS)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 bg-[#0d0f14] py-4 px-6 text-center text-xs font-mono text-zinc-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Fruit Ninja Auto Bot • Real Android Mobile Controller (AccessibilityService + CV)</span>
          <span className="text-zinc-600">Built for high-combo automation and bomb avoidance</span>
        </div>
      </footer>
    </div>
  );
}
