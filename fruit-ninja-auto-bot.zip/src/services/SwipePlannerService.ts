import { Point2D, DetectedItem, SwipePath, BotSpeed, SwipeStyle } from '../types';

export class SwipePlannerService {
  private bombSafetyRadius: number = 0.16; // Normalized (16% of screen min dimension)
  private swipeStyle: SwipeStyle = 'smart_bezier';

  public setBombSafetyRadius(radius: number) {
    this.bombSafetyRadius = radius;
  }

  public setSwipeStyle(style: SwipeStyle) {
    this.swipeStyle = style;
  }

  /**
   * Plans the safest, highest-scoring blade trajectory for active fruits while avoiding bombs.
   */
  public planSwipe(
    fruits: DetectedItem[],
    bombs: DetectedItem[],
    speed: BotSpeed
  ): SwipePath | null {
    const activeFruits = fruits.filter((f) => !f.isSliced);
    if (activeFruits.length === 0) return null;

    // Calculate base swipe duration according to bot speed
    const durationMs = speed === 'fast' ? 50 : speed === 'normal' ? 90 : 160;

    let bestPath: SwipePath | null = null;
    let maxHitCount = 0;
    let highestSafety = -1;

    // Phase 1: Try combo swipes (2, 3 or more fruits in a clean line/curve)
    if (activeFruits.length >= 2) {
      for (let i = 0; i < activeFruits.length; i++) {
        for (let j = i + 1; j < activeFruits.length; j++) {
          const f1 = activeFruits[i];
          const f2 = activeFruits[j];

          const comboPath = this.evaluateMultiFruitSwipe(
            f1,
            f2,
            activeFruits,
            bombs,
            durationMs
          );

          if (comboPath && !comboPath.isBombCollisionRisk) {
            if (
              comboPath.targetFruitIds.length > maxHitCount ||
              (comboPath.targetFruitIds.length === maxHitCount &&
                comboPath.safetyScore > highestSafety)
            ) {
              bestPath = comboPath;
              maxHitCount = comboPath.targetFruitIds.length;
              highestSafety = comboPath.safetyScore;
            }
          }
        }
      }
    }

    // Phase 2: If no safe multi-combo, find best safe single fruit slice
    if (!bestPath) {
      // Prioritize fruits closest to falling off screen (highest Y value or highest velocity down)
      const sortedByUrgency = [...activeFruits].sort((a, b) => b.y - a.y);

      for (const fruit of sortedByUrgency) {
        const singlePath = this.evaluateSingleFruitSwipe(fruit, bombs, durationMs);
        if (singlePath && !singlePath.isBombCollisionRisk) {
          bestPath = singlePath;
          break;
        }
      }
    }

    return bestPath;
  }

  private evaluateSingleFruitSwipe(
    fruit: DetectedItem,
    bombs: DetectedItem[],
    durationMs: number
  ): SwipePath | null {
    // 45 degree katana slash across fruit center
    const slashLength = fruit.radius * 2.2;
    const angle = Math.PI / 4; // 45 degrees
    const dx = slashLength * Math.cos(angle);
    const dy = slashLength * Math.sin(angle);

    const pStart: Point2D = {
      x: Math.max(0.02, Math.min(0.98, fruit.x - dx)),
      y: Math.max(0.02, Math.min(0.98, fruit.y + dy)),
    };
    const pEnd: Point2D = {
      x: Math.max(0.02, Math.min(0.98, fruit.x + dx)),
      y: Math.max(0.02, Math.min(0.98, fruit.y - dy)),
    };

    const isRisk = this.checkBombCollision(pStart, pEnd, bombs);
    if (isRisk) return null;

    const minDistanceToBomb = this.getMinDistanceToAnyBomb([pStart, pEnd], bombs);
    const safetyScore = Math.min(100, Math.round((minDistanceToBomb / 0.3) * 100));

    return {
      id: `swipe_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      points: [pStart, { x: fruit.x, y: fruit.y }, pEnd],
      targetFruitIds: [fruit.id],
      avoidsBombIds: bombs.map((b) => b.id),
      safetyScore: Math.max(70, safetyScore),
      durationMs,
      timestamp: Date.now(),
      isBombCollisionRisk: false,
    };
  }

  private evaluateMultiFruitSwipe(
    f1: DetectedItem,
    f2: DetectedItem,
    allFruits: DetectedItem[],
    bombs: DetectedItem[],
    durationMs: number
  ): SwipePath | null {
    // Extended line from f1 through f2 with lead-in and lead-out margins
    const dirX = f2.x - f1.x;
    const dirY = f2.y - f1.y;
    const len = Math.hypot(dirX, dirY);
    if (len < 0.05) return null;

    const normX = dirX / len;
    const normY = dirY / len;
    const margin = 0.06;

    const pStart: Point2D = {
      x: Math.max(0.02, Math.min(0.98, f1.x - normX * margin)),
      y: Math.max(0.02, Math.min(0.98, f1.y - normY * margin)),
    };
    const pEnd: Point2D = {
      x: Math.max(0.02, Math.min(0.98, f2.x + normX * margin)),
      y: Math.max(0.02, Math.min(0.98, f2.y + normY * margin)),
    };

    // Check if line passes through bomb zones
    if (this.checkBombCollision(pStart, pEnd, bombs)) {
      return null;
    }

    // Collect all fruits intersected
    const hitFruitIds: string[] = [];
    for (const fruit of allFruits) {
      const dist = this.distancePointToSegment({ x: fruit.x, y: fruit.y }, pStart, pEnd);
      if (dist <= fruit.radius * 1.5) {
        hitFruitIds.push(fruit.id);
      }
    }

    if (hitFruitIds.length === 0) return null;

    // Generate smooth path points
    const midPoint: Point2D = {
      x: (pStart.x + pEnd.x) / 2,
      y: (pStart.y + pEnd.y) / 2,
    };

    const minDistanceToBomb = this.getMinDistanceToAnyBomb([pStart, midPoint, pEnd], bombs);
    const safetyScore = Math.min(100, Math.round((minDistanceToBomb / 0.3) * 100));

    return {
      id: `combo_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      points: [pStart, midPoint, pEnd],
      targetFruitIds: hitFruitIds,
      avoidsBombIds: bombs.map((b) => b.id),
      safetyScore: Math.max(60, safetyScore),
      durationMs: Math.round(durationMs * 1.3),
      timestamp: Date.now(),
      isBombCollisionRisk: false,
    };
  }

  private checkBombCollision(p1: Point2D, p2: Point2D, bombs: DetectedItem[]): boolean {
    for (const bomb of bombs) {
      const dist = this.distancePointToSegment({ x: bomb.x, y: bomb.y }, p1, p2);
      const threshold = bomb.radius + this.bombSafetyRadius;
      if (dist < threshold) {
        return true; // Bomb collision danger!
      }
    }
    return false;
  }

  private getMinDistanceToAnyBomb(points: Point2D[], bombs: DetectedItem[]): number {
    if (bombs.length === 0) return 1.0;
    let minDist = 1.0;
    for (const bomb of bombs) {
      for (let i = 0; i < points.length - 1; i++) {
        const d = this.distancePointToSegment(
          { x: bomb.x, y: bomb.y },
          points[i],
          points[i + 1]
        );
        if (d < minDist) minDist = d;
      }
    }
    return minDist;
  }

  private distancePointToSegment(p: Point2D, a: Point2D, b: Point2D): number {
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    if (dx === 0 && dy === 0) {
      return Math.hypot(p.x - a.x, p.y - a.y);
    }
    const t = Math.max(
      0,
      Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy))
    );
    const projX = a.x + t * dx;
    const projY = a.y + t * dy;
    return Math.hypot(p.x - projX, p.y - projY);
  }
}

export const swipePlannerService = new SwipePlannerService();
