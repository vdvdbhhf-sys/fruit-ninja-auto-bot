import React from 'react';
import {
  Play,
  Square,
  ShieldAlert,
  Flame,
  Bomb,
  Zap,
  RotateCcw,
  Layers,
  Bug,
  Clock,
  Award,
  CheckCircle2,
  AlertTriangle,
  Radio,
  ExternalLink,
  ChevronRight,
} from 'lucide-react';
import { BotState, BotSettings, BotMetrics, PermissionStatus } from '../types';
import { ninjaAudio } from '../services/AudioService';

interface DashboardProps {
  botState: BotState;
  settings: BotSettings;
  metrics: BotMetrics;
  permissions: PermissionStatus;
  onStartBot: () => void;
  onStopBot: () => void;
  onEmergencyStop: () => void;
  onUpdateSettings: (newSettings: Partial<BotSettings>) => void;
  onGrantPermission: (perm: keyof PermissionStatus) => void;
  onNavigateTab: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  botState,
  settings,
  metrics,
  permissions,
  onStartBot,
  onStopBot,
  onEmergencyStop,
  onUpdateSettings,
  onGrantPermission,
  onNavigateTab,
}) => {
  const isRunning = botState !== 'IDLE' && botState !== 'STOPPED' && botState !== 'ERROR';

  const formatSessionTime = (startTime: number | null) => {
    if (!startTime) return '00:00:00';
    const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
    const hrs = Math.floor(elapsedSeconds / 3600);
    const mins = Math.floor((elapsedSeconds % 3600) / 60);
    const secs = elapsedSeconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins
      .toString()
      .padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const stateSteps: { key: BotState; label: string; desc: string }[] = [
    { key: 'IDLE', label: 'Idle Standby', desc: 'Awaiting launch command' },
    { key: 'WAITING_FOR_GAME', label: 'App Detect', desc: 'Detecting Fruit Ninja in foreground' },
    { key: 'PLAYING', label: 'Active Slicing', desc: 'Real-time CV swipe execution' },
    { key: 'GAME_OVER', label: 'Game Over', desc: 'Game session ended' },
    { key: 'RESULT_SCREEN', label: 'Result Screen', desc: 'Scanning for Replay/Continue buttons' },
    { key: 'ADVERTISEMENT', label: 'Ad Interstitial', desc: 'Monitoring ad timer for Skip/Close' },
    { key: 'STARTING_NEW_GAME', label: 'Auto Restart', desc: 'Dispatching Play/Start tap' },
  ];

  return (
    <div id="dashboard-view" className="space-y-6">
      {/* Top Banner Alert if permissions missing */}
      {(permissions.accessibilityService !== 'granted' ||
        permissions.screenCapture !== 'granted' ||
        permissions.overlayPermission !== 'granted') && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-amber-300">Android Permissions Required</h4>
              <p className="text-xs text-zinc-400">
                AccessibilityService, Screen Capture (MediaProjection), and Floating Overlay must be enabled to control Fruit Ninja.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
            {permissions.accessibilityService !== 'granted' && (
              <button
                onClick={() => onGrantPermission('accessibilityService')}
                className="px-3 py-1.5 text-xs font-mono font-medium rounded-lg bg-amber-600 hover:bg-amber-500 text-black font-bold transition-colors"
              >
                Enable Accessibility
              </button>
            )}
            {permissions.screenCapture !== 'granted' && (
              <button
                onClick={() => onGrantPermission('screenCapture')}
                className="px-3 py-1.5 text-xs font-mono font-medium rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-300 border border-amber-500/30 transition-colors"
              >
                Grant Screen Cap
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Bot Control Hero */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hero Action Card */}
        <div className="lg:col-span-2 ninja-panel rounded-2xl p-6 relative overflow-hidden flex flex-col justify-between border-orange-500/20">
          <div className="absolute top-0 right-0 w-80 h-80 bg-orange-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-orange-500/20 text-orange-400">
                  <Flame className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-lg font-bold text-white tracking-wide">Blade Automation Core</h2>
                  <p className="text-xs text-zinc-400">Direct AccessibilityService gesture driver</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-zinc-400">STATE:</span>
                <span className="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-zinc-900 border border-zinc-700 text-orange-400">
                  {botState}
                </span>
              </div>
            </div>

            {/* Big Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
              {!isRunning ? (
                <button
                  id="dashboard-start-bot-btn"
                  onClick={() => {
                    ninjaAudio.playSlash();
                    onStartBot();
                  }}
                  className="py-4 px-6 rounded-xl bg-gradient-to-r from-[#ff5e00] to-[#ff8c00] hover:from-[#ff6f1a] hover:to-[#ffa01a] text-white font-ninja text-2xl font-bold tracking-wider uppercase flex items-center justify-center gap-3 blade-glow-lg transition-all transform active:scale-98 cursor-pointer group shadow-xl"
                >
                  <Play className="w-7 h-7 fill-current group-hover:scale-110 transition-transform" />
                  START AUTO BOT
                </button>
              ) : (
                <button
                  id="dashboard-stop-bot-btn"
                  onClick={() => {
                    ninjaAudio.playButtonClick();
                    onStopBot();
                  }}
                  className="py-4 px-6 rounded-xl bg-gradient-to-r from-zinc-700 to-zinc-800 hover:from-zinc-600 hover:to-zinc-700 text-zinc-100 font-ninja text-2xl font-bold tracking-wider uppercase flex items-center justify-center gap-3 border border-zinc-600 transition-all transform active:scale-98 cursor-pointer shadow-xl"
                >
                  <Square className="w-6 h-6 fill-current" />
                  STOP BOT
                </button>
              )}

              <button
                id="dashboard-emergency-stop-btn"
                onClick={() => {
                  ninjaAudio.playEmergencyStop();
                  onEmergencyStop();
                }}
                className="py-4 px-6 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 text-white font-ninja text-2xl font-bold tracking-wider uppercase flex items-center justify-center gap-3 blade-glow-danger border border-red-400 transition-all transform active:scale-98 cursor-pointer shadow-xl"
              >
                <ShieldAlert className="w-7 h-7" />
                EMERGENCY STOP
              </button>
            </div>
          </div>

          {/* Speed Selector & Auto-Restart Toggles */}
          <div className="pt-4 border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs text-zinc-400 font-mono flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                SWIPE SPEED:
              </span>
              <div className="flex rounded-lg bg-zinc-900 p-1 border border-zinc-800">
                {(['slow', 'normal', 'fast'] as const).map((speed) => (
                  <button
                    key={speed}
                    onClick={() => {
                      ninjaAudio.playButtonClick();
                      onUpdateSettings({ swipeSpeed: speed });
                    }}
                    className={`px-3 py-1 text-xs font-mono uppercase rounded transition-all ${
                      settings.swipeSpeed === speed
                        ? 'bg-[#ff5e00] text-white font-bold shadow-md'
                        : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {speed}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-zinc-300">
                <input
                  type="checkbox"
                  checked={settings.autoRestart}
                  onChange={(e) => onUpdateSettings({ autoRestart: e.target.checked })}
                  className="rounded border-zinc-700 text-orange-500 focus:ring-0 w-4 h-4 accent-orange-500"
                />
                <RotateCcw className="w-3.5 h-3.5 text-orange-400" />
                Auto Restart
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-zinc-300">
                <input
                  type="checkbox"
                  checked={settings.showFloatingOverlay}
                  onChange={(e) => onUpdateSettings({ showFloatingOverlay: e.target.checked })}
                  className="rounded border-zinc-700 text-orange-500 focus:ring-0 w-4 h-4 accent-orange-500"
                />
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                Floating HUD
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs font-mono text-zinc-300">
                <input
                  type="checkbox"
                  checked={settings.debugMode}
                  onChange={(e) => onUpdateSettings({ debugMode: e.target.checked })}
                  className="rounded border-zinc-700 text-orange-500 focus:ring-0 w-4 h-4 accent-orange-500"
                />
                <Bug className="w-3.5 h-3.5 text-emerald-400" />
                Debug Mode
              </label>
            </div>
          </div>
        </div>

        {/* Live Telemetry Card */}
        <div className="ninja-panel rounded-2xl p-6 flex flex-col justify-between border-zinc-800">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-zinc-200 uppercase tracking-wider flex items-center gap-2 font-mono">
                <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                Session Telemetry
              </h3>
              <span className="text-[11px] font-mono text-zinc-500">Live 60Hz</span>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800/80">
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
                  <Award className="w-3.5 h-3.5 text-orange-400" />
                  <span>Games Played</span>
                </div>
                <div className="text-2xl font-ninja font-bold text-white tracking-wider">
                  {metrics.gamesPlayed}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800/80">
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Session Time</span>
                </div>
                <div className="text-xl font-mono font-bold text-cyan-300">
                  {formatSessionTime(metrics.sessionStartTime)}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800/80">
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
                  <Flame className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Fruits Sliced</span>
                </div>
                <div className="text-2xl font-ninja font-bold text-emerald-400 tracking-wider">
                  {metrics.fruitsSliced}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800/80">
                <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
                  <Bomb className="w-3.5 h-3.5 text-rose-400" />
                  <span>Bombs Avoided</span>
                </div>
                <div className="text-2xl font-ninja font-bold text-rose-400 tracking-wider">
                  {metrics.bombsAvoided}
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/60 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Current Combo:</span>
                <span className="text-amber-400 font-bold">{metrics.currentCombo}x (Max {metrics.maxCombo}x)</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Avg Reaction Time:</span>
                <span className="text-zinc-200">{metrics.avgReactionTimeMs} ms</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Gestures Dispatched:</span>
                <span className="text-zinc-200">{metrics.gesturesExecuted}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('vision')}
            className="w-full mt-4 py-2 px-3 rounded-lg bg-zinc-800/80 hover:bg-zinc-700 text-xs font-mono text-orange-400 border border-orange-500/30 flex items-center justify-center gap-1.5 transition-colors"
          >
            Open Live Computer Vision Radar
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Android Services & Permissions Status Card */}
      <div className="ninja-panel rounded-2xl p-6 border-zinc-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-orange-400" />
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
              Android Automation Subsystems
            </h3>
          </div>
          <span className="text-xs text-zinc-400 font-mono">No Root • No ADB Required</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Subsystem 1: Accessibility */}
          <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-zinc-200 font-mono">AccessibilityService</span>
                {permissions.accessibilityService === 'granted' ? (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    <CheckCircle2 className="w-3 h-3" /> ACTIVE
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    DISABLED
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-400 mb-3">
                Inspects <code className="text-orange-300 font-mono">AccessibilityNodeInfo</code> for Play/Replay/Skip buttons and dispatches swipe strokes via <code className="text-orange-300 font-mono">dispatchGesture</code>.
              </p>
            </div>
            {permissions.accessibilityService !== 'granted' && (
              <button
                onClick={() => onGrantPermission('accessibilityService')}
                className="w-full py-1.5 px-3 rounded-lg bg-orange-600 hover:bg-orange-500 text-black font-mono text-xs font-bold transition-colors"
              >
                Enable in Android Settings
              </button>
            )}
          </div>

          {/* Subsystem 2: Screen Capture */}
          <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-zinc-200 font-mono">MediaProjection CV Capture</span>
                {permissions.screenCapture === 'granted' ? (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    <CheckCircle2 className="w-3 h-3" /> CAPTURING
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    PROMPT
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-400 mb-3">
                Captures real-time frames via <code className="text-orange-300 font-mono">ImageReader</code> in RGBA_8888 for fruit color segmentation & bomb fuse spark detection.
              </p>
            </div>
            {permissions.screenCapture !== 'granted' && (
              <button
                onClick={() => onGrantPermission('screenCapture')}
                className="w-full py-1.5 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-300 border border-amber-500/30 font-mono text-xs font-medium transition-colors"
              >
                Prompt Capture Permission
              </button>
            )}
          </div>

          {/* Subsystem 3: Floating Overlay */}
          <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-zinc-200 font-mono">Floating Window Overlay</span>
                {permissions.overlayPermission === 'granted' ? (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    <CheckCircle2 className="w-3 h-3" /> OVERLAY ON
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[11px] font-mono text-zinc-500 bg-zinc-800/40 px-2 py-0.5 rounded">
                    DISABLED
                  </span>
                )}
              </div>
              <p className="text-xs text-zinc-400 mb-3">
                Renders a draggable non-intrusive HUD on top of Fruit Ninja using Android <code className="text-orange-300 font-mono">WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY</code>.
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('overlay')}
              className="w-full py-1.5 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-cyan-400 border border-cyan-500/30 font-mono text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
            >
              Test Floating HUD
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* State Machine Visualization */}
      <div className="ninja-panel rounded-2xl p-6 border-zinc-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-zinc-200 font-mono uppercase tracking-wider">
            Deterministic Finite Game State Loop
          </h3>
          <span className="text-xs text-zinc-400 font-mono">Current: {botState}</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {stateSteps.map((step) => {
            const isActive = botState === step.key;
            return (
              <div
                key={step.key}
                className={`p-3 rounded-xl border text-center transition-all ${
                  isActive
                    ? 'bg-[#ff5e00]/20 border-[#ff5e00] blade-glow text-orange-300'
                    : 'bg-zinc-900/60 border-zinc-800/80 text-zinc-500'
                }`}
              >
                <div className="text-xs font-bold font-mono uppercase mb-1">{step.label}</div>
                <div className="text-[10px] line-clamp-2 leading-tight">{step.desc}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
