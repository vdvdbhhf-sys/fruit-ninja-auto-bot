import React from 'react';
import { Swords, ShieldAlert, Volume2, VolumeX, Smartphone } from 'lucide-react';
import { BotState } from '../types';
import { ninjaAudio } from '../services/AudioService';

interface NavbarProps {
  botState: BotState;
  onEmergencyStop: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  overlayActive: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  botState,
  onEmergencyStop,
  isMuted,
  onToggleMute,
  activeTab,
  onTabChange,
  overlayActive,
}) => {
  const getStateColor = (state: BotState) => {
    switch (state) {
      case 'PLAYING':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 animate-pulse';
      case 'WAITING_FOR_GAME':
      case 'STARTING_NEW_GAME':
        return 'bg-amber-500/20 text-amber-400 border-amber-500/40';
      case 'ADVERTISEMENT':
      case 'WAITING_FOR_CLOSE':
        return 'bg-purple-500/20 text-purple-400 border-purple-500/40';
      case 'GAME_OVER':
      case 'RESULT_SCREEN':
        return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40';
      case 'STOPPED':
      case 'ERROR':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
      default:
        return 'bg-zinc-800/60 text-zinc-400 border-zinc-700/50';
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'vision', label: 'Vision & Radar' },
    { id: 'calibration', label: 'CV Workbench' },
    { id: 'overlay', label: 'Floating HUD' },
    { id: 'native', label: 'Android Source' },
    { id: 'logs', label: 'Logs' },
    { id: 'settings', label: 'Settings' },
  ];

  return (
    <header id="app-navbar" className="sticky top-0 z-40 bg-[#0d0f14]/95 border-b border-zinc-800/80 backdrop-blur-md px-4 py-2.5">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Brand & State */}
        <div className="flex items-center justify-between w-full md:w-auto gap-3">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onTabChange('dashboard')}>
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#ff5e00] to-[#e62020] flex items-center justify-center shadow-lg shadow-orange-500/25 blade-glow">
              <Swords className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-ninja text-2xl font-bold tracking-wide text-white leading-none">
                  FRUIT NINJA <span className="text-[#ff6a00]">AUTO BOT</span>
                </span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
                  v1.0 Native
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 font-mono">Real Android Mobile Automation</p>
            </div>
          </div>

          <div className="flex items-center gap-2 md:hidden">
            <button
              id="mobile-emergency-stop-btn"
              onClick={onEmergencyStop}
              className="px-2.5 py-1 text-xs font-bold font-mono bg-rose-600 hover:bg-rose-700 text-white rounded border border-rose-400 blade-glow-danger flex items-center gap-1"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              EMG STOP
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`nav-tab-${item.id}`}
              onClick={() => {
                ninjaAudio.playButtonClick();
                onTabChange(item.id);
              }}
              className={`px-3 py-1.5 rounded-md text-xs font-medium tracking-wider uppercase transition-all whitespace-nowrap ${
                activeTab === item.id
                  ? 'bg-gradient-to-r from-[#ff5e00]/20 to-[#ff9100]/20 text-[#ff8000] border border-[#ff5e00]/40 font-semibold shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* State Pill, Floating Overlay Status & Emergency Action */}
        <div className="hidden md:flex items-center gap-3">
          {overlayActive && (
            <div className="flex items-center gap-1 text-[11px] font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-800/60 px-2 py-0.5 rounded">
              <Smartphone className="w-3 h-3 animate-pulse" />
              Overlay ON
            </div>
          )}

          <div
            className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold tracking-wider uppercase border flex items-center gap-1.5 ${getStateColor(
              botState
            )}`}
          >
            <span className="w-2 h-2 rounded-full bg-current"></span>
            {botState.replace(/_/g, ' ')}
          </div>

          <button
            id="audio-toggle-btn"
            onClick={onToggleMute}
            title={isMuted ? 'Unmute blade audio' : 'Mute blade audio'}
            className="p-1.5 rounded-md bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 transition-colors border border-zinc-700/50"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-orange-400" />}
          </button>

          <button
            id="navbar-emergency-stop-btn"
            onClick={() => {
              ninjaAudio.playEmergencyStop();
              onEmergencyStop();
            }}
            className="px-3 py-1.5 text-xs font-bold font-mono bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white rounded-md border border-rose-400/80 shadow-md blade-glow-danger flex items-center gap-1.5 transition-all transform active:scale-95"
          >
            <ShieldAlert className="w-4 h-4" />
            EMERGENCY STOP
          </button>
        </div>
      </div>
    </header>
  );
};
