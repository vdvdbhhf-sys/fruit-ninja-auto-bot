import React from 'react';
import {
  Settings as SettingsIcon,
  Sliders,
  RotateCcw,
  Zap,
  Bomb,
  Layers,
  Clock,
  Volume2,
  Bug,
  ShieldCheck,
} from 'lucide-react';
import { BotSettings } from '../types';
import { ninjaAudio } from '../services/AudioService';

interface SettingsModalProps {
  settings: BotSettings;
  onUpdateSettings: (newSettings: Partial<BotSettings>) => void;
  onResetDefaults: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onResetDefaults,
}) => {
  return (
    <div id="settings-view" className="space-y-6">
      {/* Top Header */}
      <div className="ninja-panel rounded-2xl p-4 flex items-center justify-between border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-orange-500/20 text-orange-400">
            <SettingsIcon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              Bot Execution & Heuristic Settings
            </h3>
            <p className="text-xs text-zinc-400 font-mono">
              Configure detection intervals, swipe physics, bomb safety buffers, and ad dismiss timeouts
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            ninjaAudio.playButtonClick();
            onResetDefaults();
          }}
          className="py-1.5 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-mono text-zinc-300 border border-zinc-700 flex items-center gap-1.5 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Defaults
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Section 1: Motion & Blade Gestures */}
        <div className="ninja-panel rounded-2xl p-6 border-zinc-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-zinc-800 text-xs font-mono font-bold text-orange-400 uppercase tracking-wider">
            <Zap className="w-4 h-4" />
            <span>Gesture & Swiping Speed</span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-zinc-300 mb-1.5">
                Swipe Speed Preset
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['slow', 'normal', 'fast'] as const).map((spd) => (
                  <button
                    key={spd}
                    onClick={() => {
                      ninjaAudio.playButtonClick();
                      onUpdateSettings({ swipeSpeed: spd });
                    }}
                    className={`py-2 text-xs font-mono uppercase rounded-lg border transition-all ${
                      settings.swipeSpeed === spd
                        ? 'bg-orange-600 border-orange-400 text-white font-bold blade-glow'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {spd}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">CV Scan Interval:</span>
                <span className="text-orange-400 font-bold">{settings.detectionIntervalMs} ms</span>
              </div>
              <input
                type="range"
                min="20"
                max="120"
                step="5"
                value={settings.detectionIntervalMs}
                onChange={(e) =>
                  onUpdateSettings({ detectionIntervalMs: parseInt(e.target.value, 10) })
                }
                className="w-full accent-orange-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-300 mb-1.5">
                Blade Slash Style
              </label>
              <select
                value={settings.swipeStyle}
                onChange={(e) =>
                  onUpdateSettings({
                    swipeStyle: e.target.value as BotSettings['swipeStyle'],
                  })
                }
                className="w-full p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-mono text-zinc-200 focus:outline-none focus:border-orange-500"
              >
                <option value="smart_bezier">Smart Bezier (Multi-Fruit Curves)</option>
                <option value="blade_linear">Direct Linear Katana Slash</option>
                <option value="multi_slice_curve">Aggressive Combo Fan</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: Bomb Clearance & Computer Vision */}
        <div className="ninja-panel rounded-2xl p-6 border-zinc-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-zinc-800 text-xs font-mono font-bold text-rose-400 uppercase tracking-wider">
            <Bomb className="w-4 h-4" />
            <span>Bomb Safety & Confidence</span>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Bomb Safety Clearance Buffer:</span>
                <span className="text-rose-400 font-bold">
                  {Math.round(settings.bombSafetyRadius * 100)}% screen
                </span>
              </div>
              <input
                type="range"
                min="0.08"
                max="0.28"
                step="0.02"
                value={settings.bombSafetyRadius}
                onChange={(e) =>
                  onUpdateSettings({ bombSafetyRadius: parseFloat(e.target.value) })
                }
                className="w-full accent-rose-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Fruit Confidence Threshold:</span>
                <span className="text-emerald-400 font-bold">
                  {Math.round(settings.fruitConfidenceThreshold * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.4"
                max="0.95"
                step="0.05"
                value={settings.fruitConfidenceThreshold}
                onChange={(e) =>
                  onUpdateSettings({ fruitConfidenceThreshold: parseFloat(e.target.value) })
                }
                className="w-full accent-emerald-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-300 mb-1.5">
                Detection Engine Backend
              </label>
              <select
                value={settings.detectionEngine}
                onChange={(e) =>
                  onUpdateSettings({
                    detectionEngine: e.target.value as BotSettings['detectionEngine'],
                  })
                }
                className="w-full p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-mono text-zinc-200 focus:outline-none focus:border-orange-500"
              >
                <option value="hybrid_cv_color">Hybrid HSV Color & Contours (Built-in Fast)</option>
                <option value="tflite_custom">TensorFlow Lite Custom Neural Model</option>
                <option value="gemini_vision_assisted">Gemini Server-Assisted Scene Analysis</option>
              </select>
            </div>
          </div>
        </div>

        {/* Section 3: Game Loop & Ad Handling */}
        <div className="ninja-panel rounded-2xl p-6 border-zinc-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-zinc-800 text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            <Clock className="w-4 h-4" />
            <span>Game Over, Restart & Ads</span>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Auto-Restart Delay:</span>
                <span className="text-cyan-400 font-bold">{settings.restartDelayMs} ms</span>
              </div>
              <input
                type="range"
                min="500"
                max="4000"
                step="250"
                value={settings.restartDelayMs}
                onChange={(e) =>
                  onUpdateSettings({ restartDelayMs: parseInt(e.target.value, 10) })
                }
                className="w-full accent-cyan-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Advertisement Timeout:</span>
                <span className="text-purple-400 font-bold">{settings.adTimeoutSeconds} seconds</span>
              </div>
              <input
                type="range"
                min="5"
                max="35"
                step="5"
                value={settings.adTimeoutSeconds}
                onChange={(e) =>
                  onUpdateSettings({ adTimeoutSeconds: parseInt(e.target.value, 10) })
                }
                className="w-full accent-purple-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">Max Games (0=∞)</label>
                <input
                  type="number"
                  min="0"
                  max="1000"
                  value={settings.maxGames}
                  onChange={(e) =>
                    onUpdateSettings({ maxGames: parseInt(e.target.value, 10) || 0 })
                  }
                  className="w-full p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-mono text-zinc-200"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-400 mb-1">Timeout Mins (0=∞)</label>
                <input
                  type="number"
                  min="0"
                  max="480"
                  value={settings.sessionTimeoutMinutes}
                  onChange={(e) =>
                    onUpdateSettings({ sessionTimeoutMinutes: parseInt(e.target.value, 10) || 0 })
                  }
                  className="w-full p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-mono text-zinc-200"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 4: System Toggles */}
        <div className="ninja-panel rounded-2xl p-6 border-zinc-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-zinc-800 text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
            <Sliders className="w-4 h-4" />
            <span>Subsystem Features</span>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 cursor-pointer">
              <span className="text-xs font-mono text-zinc-200 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-orange-400" />
                Auto Restart Loop
              </span>
              <input
                type="checkbox"
                checked={settings.autoRestart}
                onChange={(e) => onUpdateSettings({ autoRestart: e.target.checked })}
                className="w-4 h-4 accent-orange-500 rounded cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 cursor-pointer">
              <span className="text-xs font-mono text-zinc-200 flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                Show Floating Overlay
              </span>
              <input
                type="checkbox"
                checked={settings.showFloatingOverlay}
                onChange={(e) => onUpdateSettings({ showFloatingOverlay: e.target.checked })}
                className="w-4 h-4 accent-orange-500 rounded cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 cursor-pointer">
              <span className="text-xs font-mono text-zinc-200 flex items-center gap-2">
                <Bug className="w-4 h-4 text-emerald-400" />
                Debug Bounding Box Overlays
              </span>
              <input
                type="checkbox"
                checked={settings.debugMode}
                onChange={(e) => onUpdateSettings({ debugMode: e.target.checked })}
                className="w-4 h-4 accent-orange-500 rounded cursor-pointer"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 cursor-pointer">
              <span className="text-xs font-mono text-zinc-200 flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-amber-400" />
                Blade Audio Synthesizer
              </span>
              <input
                type="checkbox"
                checked={settings.enableSoundEffects}
                onChange={(e) => onUpdateSettings({ enableSoundEffects: e.target.checked })}
                className="w-4 h-4 accent-orange-500 rounded cursor-pointer"
              />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
