import React, { useState } from 'react';
import {
  FileCode,
  Download,
  Copy,
  Check,
  FolderTree,
  FileText,
  Terminal,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import JSZip from 'jszip';
import confetti from 'canvas-confetti';
import { ANDROID_SOURCE_FILES, AndroidFile } from '../native-android/androidSourceFiles';
import { ninjaAudio } from '../services/AudioService';

export const NativeSourceExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(ANDROID_SOURCE_FILES[3]); // Default to AccessibilityService.kt
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    ninjaAudio.playButtonClick();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportZip = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();
      const rootFolder = zip.folder('FruitNinjaAutoBot_Android');

      ANDROID_SOURCE_FILES.forEach((file) => {
        rootFolder?.file(file.path, file.code);
      });

      // Add README.md with build instructions
      rootFolder?.file(
        'README.md',
        `# Fruit Ninja Auto Bot - Android Native Project

This is a real Android mobile automation controller for Fruit Ninja.

## Core Features
1. **AccessibilityService**: Real non-root gesture dispatching and AccessibilityNodeInfo UI button clicker.
2. **MediaProjection Screen Capture**: Continuous RGBA_8888 frame capture.
3. **Computer Vision & Bomb Avoidance**: Modular FruitDetectionEngine + BombDetectionEngine + Safe SwipePlanner.
4. **WindowManager Floating Overlay**: Draggable interactive HUD rendered directly on top of Fruit Ninja.
5. **Ad Interstitial Handler**: Automatic Skip/Close dismissals.

## Build Steps
1. Open this folder in Android Studio (Iguana / Jellyfish / Ladybug+).
2. Sync Gradle files.
3. Build and install APK on your Android device (Android 8.0+ / API 26+).
4. Launch app and grant Accessibility, MediaProjection, and Overlay permissions.
5. Launch Fruit Ninja and enjoy automated high-combo gameplay!
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'FruitNinjaAutoBot_Android_Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
      ninjaAudio.playFruitSlice();
    } catch {
      alert('Failed to generate zip file');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div id="native-source-explorer" className="space-y-6">
      {/* Top Header & Export Action */}
      <div className="ninja-panel rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-orange-500/20 text-orange-400">
            <FileCode className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              Production Native Android Source Code (Kotlin & Gradle)
            </h3>
            <p className="text-xs text-zinc-400 font-mono">
              Complete implementation of AccessibilityService, WindowManager Overlay, and CV Swipe Planner
            </p>
          </div>
        </div>

        <button
          id="export-android-project-zip-btn"
          onClick={handleExportZip}
          disabled={isExporting}
          className="py-2 px-4 rounded-xl bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg blade-glow transition-all"
        >
          <Download className="w-4 h-4" />
          {isExporting ? 'Packaging ZIP...' : 'Export Android Studio Project (.zip)'}
        </button>
      </div>

      {/* Main Code Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left File Tree Sidebar */}
        <div className="ninja-panel rounded-2xl p-4 border-zinc-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider pb-2 border-b border-zinc-800">
            <FolderTree className="w-4 h-4 text-orange-400" />
            <span>Android Project Files</span>
          </div>

          <div className="space-y-1 overflow-y-auto max-h-[580px] scrollbar-none">
            {ANDROID_SOURCE_FILES.map((file) => (
              <button
                key={file.path}
                onClick={() => {
                  ninjaAudio.playButtonClick();
                  setSelectedFile(file);
                }}
                className={`w-full text-left p-2 rounded-lg text-xs font-mono transition-colors flex items-center gap-2 ${
                  selectedFile.path === file.path
                    ? 'bg-orange-500/20 text-orange-300 border border-orange-500/40 font-bold'
                    : 'text-zinc-400 hover:bg-zinc-800/60 hover:text-zinc-200'
                }`}
              >
                <FileText className="w-3.5 h-3.5 flex-shrink-0 text-zinc-500" />
                <span className="truncate">{file.name}</span>
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-zinc-800 text-[11px] font-mono text-zinc-500">
            Target SDK: 34 (Android 14) • Min SDK: 26 (Android 8.0)
          </div>
        </div>

        {/* Right Code Viewer */}
        <div className="lg:col-span-3 ninja-panel rounded-2xl p-5 border-zinc-800 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div>
                <h4 className="text-sm font-bold text-white font-mono flex items-center gap-2">
                  <span>{selectedFile.path}</span>
                </h4>
                <p className="text-xs text-zinc-400 mt-0.5">{selectedFile.description}</p>
              </div>

              <button
                onClick={handleCopy}
                className="py-1.5 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-mono text-xs flex items-center gap-1.5 border border-zinc-700 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy Code'}
              </button>
            </div>

            {/* Code container */}
            <div className="mt-4 rounded-xl bg-zinc-950 p-4 border border-zinc-800 overflow-x-auto max-h-[500px]">
              <pre className="font-mono-code text-xs text-zinc-300 leading-relaxed">
                <code>{selectedFile.code}</code>
              </pre>
            </div>
          </div>

          {/* Android Architecture Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-3 border-t border-zinc-800">
            <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80">
              <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400 mb-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> No Root Required
              </div>
              <p className="text-[11px] text-zinc-400">
                Uses official Android <code className="text-orange-300">AccessibilityService.dispatchGesture</code>.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80">
              <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-400 mb-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Bomb Clearance
              </div>
              <p className="text-[11px] text-zinc-400">
                Guaranteed distance-to-segment clearance corridor on all swipe paths.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80">
              <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-purple-400 mb-1">
                <Terminal className="w-3.5 h-3.5" /> Ad Auto Dismiss
              </div>
              <p className="text-[11px] text-zinc-400">
                Heuristic hierarchy node traversal for Skip & Close/X actions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
