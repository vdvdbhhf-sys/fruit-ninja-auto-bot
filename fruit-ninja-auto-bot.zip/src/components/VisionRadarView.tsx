import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Eye,
  Camera,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Bomb,
  Plus,
  Shield,
  Zap,
  Target,
  Maximize2,
  Tv,
} from 'lucide-react';
import { DetectedItem, SwipePath, BotSettings, BotState } from '../types';
import { swipePlannerService } from '../services/SwipePlannerService';
import { ninjaAudio } from '../services/AudioService';

interface VisionRadarViewProps {
  botState: BotState;
  settings: BotSettings;
  onSliceFruit: (count: number) => void;
  onAvoidBomb: () => void;
  onRecordGesture: (swipe: SwipePath) => void;
}

export const VisionRadarView: React.FC<VisionRadarViewProps> = ({
  botState,
  settings,
  onSliceFruit,
  onAvoidBomb,
  onRecordGesture,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const [isPaused, setIsPaused] = useState(false);
  const [activeItems, setActiveItems] = useState<DetectedItem[]>([]);
  const [lastPlannedSwipe, setLastPlannedSwipe] = useState<SwipePath | null>(null);
  const [bladeTrail, setBladeTrail] = useState<{ x: number; y: number; alpha: number }[]>([]);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [fps, setFps] = useState(60);

  // Spawn preset fruit varieties
  const fruitTemplates = [
    { name: 'Watermelon', color: '#22c55e', radius: 0.08, type: 'fruit' as const },
    { name: 'Banana', color: '#eab308', radius: 0.065, type: 'fruit' as const },
    { name: 'Red Apple', color: '#ef4444', radius: 0.06, type: 'fruit' as const },
    { name: 'Orange', color: '#f97316', radius: 0.065, type: 'fruit' as const },
    { name: 'Pineapple', color: '#fbbf24', radius: 0.085, type: 'fruit' as const },
    { name: 'Strawberry', color: '#f43f5e', radius: 0.05, type: 'fruit' as const },
  ];

  // Helper to spawn a new item in simulation
  const spawnItem = useCallback((type: 'fruit' | 'bomb', specificName?: string, customPos?: { x: number; y: number }) => {
    const isBomb = type === 'bomb';
    const template = specificName
      ? fruitTemplates.find((f) => f.name === specificName) || fruitTemplates[0]
      : fruitTemplates[Math.floor(Math.random() * fruitTemplates.length)];

    const newItem: DetectedItem = {
      id: `item_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type,
      name: isBomb ? 'BOMB' : template.name,
      color: isBomb ? '#111827' : template.color,
      x: customPos ? customPos.x : 0.2 + Math.random() * 0.6,
      y: customPos ? customPos.y : 0.95, // Launches from bottom
      radius: isBomb ? 0.075 : template.radius,
      confidence: isBomb ? 0.92 + Math.random() * 0.07 : 0.85 + Math.random() * 0.14,
      velocityX: (Math.random() - 0.5) * 0.008,
      velocityY: -(0.014 + Math.random() * 0.006), // Initial upward velocity
      isSliced: false,
    };

    setActiveItems((prev) => [...prev, newItem]);
  }, [fruitTemplates]);

  // Spawn a multi-fruit wave
  const spawnWave = (withBomb = true) => {
    spawnItem('fruit', 'Watermelon', { x: 0.35, y: 0.95 });
    setTimeout(() => spawnItem('fruit', 'Banana', { x: 0.55, y: 0.95 }), 80);
    setTimeout(() => spawnItem('fruit', 'Red Apple', { x: 0.7, y: 0.95 }), 160);
    if (withBomb) {
      setTimeout(() => spawnItem('bomb', undefined, { x: 0.48, y: 0.92 }), 100);
    }
  };

  // Start live screen / camera capture
  const handleStartScreenShare = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: { frameRate: 30 },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          setIsScreenSharing(true);
        }
      } else {
        alert('Screen capture API is not available on this browser.');
      }
    } catch {
      // User cancelled prompt
    }
  };

  const handleStopScreenShare = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
      setIsScreenSharing(false);
    }
  };

  // Main Simulation & CV Loop
  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let lastFpsUpdate = performance.now();

    const gravity = 0.00028;

    const renderLoop = (time: number) => {
      animationFrameId = requestAnimationFrame(renderLoop);
      if (isPaused) return;

      const delta = time - lastTime;
      lastTime = time;

      frameCount++;
      if (time - lastFpsUpdate >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastFpsUpdate = time;
      }

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const width = canvas.width;
      const height = canvas.height;

      // 1. Draw Background (Dark Dojo Wood & Bamboo grid)
      ctx.fillStyle = '#0e1017';
      ctx.fillRect(0, 0, width, height);

      // If video screen share is active, render video beneath
      if (isScreenSharing && videoRef.current && videoRef.current.readyState >= 2) {
        ctx.save();
        ctx.globalAlpha = 0.65;
        ctx.drawImage(videoRef.current, 0, 0, width, height);
        ctx.restore();
      }

      // Dojo grid lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // 2. Physics Update for Active Items
      setActiveItems((currentItems) => {
        const updated = currentItems
          .map((item) => {
            const nextX = item.x + (item.velocityX || 0);
            const nextY = item.y + (item.velocityY || 0);
            const nextVelY = (item.velocityY || 0) + gravity;

            return {
              ...item,
              x: nextX,
              y: nextY,
              velocityY: nextVelY,
            };
          })
          .filter((item) => item.y < 1.15 && item.x > -0.1 && item.x < 1.1); // Drop off screen

        // Autonomous Spawning if playing and screen is empty
        if (botState === 'PLAYING' && updated.length < 2 && Math.random() < 0.035) {
          if (Math.random() < 0.25) {
            spawnItem('bomb');
          } else {
            spawnItem('fruit');
          }
        }

        return updated;
      });

      // 3. Computer Vision & Swipe Planning
      const activeFruits = activeItems.filter((i) => i.type === 'fruit' && !i.isSliced);
      const activeBombs = activeItems.filter((i) => i.type === 'bomb');

      swipePlannerService.setBombSafetyRadius(settings.bombSafetyRadius);
      swipePlannerService.setSwipeStyle(settings.swipeStyle);

      const plannedSwipe = swipePlannerService.planSwipe(
        activeFruits,
        activeBombs,
        settings.swipeSpeed
      );

      if (plannedSwipe) {
        setLastPlannedSwipe(plannedSwipe);

        // Execute swipe if bot is active (or in debug auto-slice)
        if (botState === 'PLAYING') {
          // Slice the targets
          const targetIds = new Set(plannedSwipe.targetFruitIds);
          let slicedCount = 0;

          setActiveItems((prev) =>
            prev.map((item) => {
              if (targetIds.has(item.id) && !item.isSliced) {
                slicedCount++;
                return { ...item, isSliced: true };
              }
              return item;
            })
          );

          if (slicedCount > 0) {
            ninjaAudio.playFruitSlice();
            onSliceFruit(slicedCount);
            if (activeBombs.length > 0) {
              onAvoidBomb();
            }
            onRecordGesture(plannedSwipe);
          }

          // Add to blade trail
          if (plannedSwipe.points.length >= 2) {
            ninjaAudio.playSlash();
            const p1 = plannedSwipe.points[0];
            const p2 = plannedSwipe.points[plannedSwipe.points.length - 1];
            setBladeTrail((prev) => [
              ...prev,
              { x: p1.x, y: p1.y, alpha: 1.0 },
              { x: p2.x, y: p2.y, alpha: 1.0 },
            ]);
          }
        }
      }

      // 4. Render Bomb Danger Zones
      for (const bomb of activeBombs) {
        const cx = bomb.x * width;
        const cy = bomb.y * height;
        const rad = bomb.radius * Math.min(width, height);
        const safeRad = (bomb.radius + settings.bombSafetyRadius) * Math.min(width, height);

        // Danger zone radius
        ctx.beginPath();
        ctx.arc(cx, cy, safeRad, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 6]);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = 'rgba(239, 68, 68, 0.08)';
        ctx.fill();

        // Bomb Body
        ctx.beginPath();
        ctx.arc(cx, cy, rad, 0, Math.PI * 2);
        ctx.fillStyle = '#18181b';
        ctx.fill();
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Spark Fuse
        const sparkAngle = (time * 0.01) % (Math.PI * 2);
        const sparkX = cx + Math.cos(sparkAngle) * (rad * 0.9);
        const sparkY = cy - rad + Math.sin(sparkAngle) * (rad * 0.4);
        ctx.beginPath();
        ctx.arc(sparkX, sparkY, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#f97316';
        ctx.fill();

        // Tag
        if (settings.debugMode) {
          ctx.fillStyle = '#ef4444';
          ctx.font = 'bold 10px JetBrains Mono, monospace';
          ctx.fillText(`BOMB [${Math.round(bomb.confidence * 100)}%]`, cx - 35, cy - rad - 8);
        }
      }

      // 5. Render Fruits
      for (const fruit of activeFruits) {
        const cx = fruit.x * width;
        const cy = fruit.y * height;
        const rad = fruit.radius * Math.min(width, height);

        ctx.save();
        ctx.beginPath();
        ctx.arc(cx, cy, rad, 0, Math.PI * 2);
        ctx.fillStyle = fruit.color;
        ctx.shadowColor = fruit.color;
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0;

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();

        // Debug Bounding Box
        if (settings.debugMode) {
          ctx.strokeStyle = 'rgba(34, 197, 94, 0.7)';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(cx - rad - 4, cy - rad - 4, (rad + 4) * 2, (rad + 4) * 2);

          ctx.fillStyle = '#22c55e';
          ctx.font = 'bold 10px JetBrains Mono, monospace';
          ctx.fillText(
            `${fruit.name} [${Math.round(fruit.confidence * 100)}%]`,
            cx - rad - 4,
            cy - rad - 8
          );
        }
      }

      // 6. Render Planned Katana Swipe Path
      if (plannedSwipe && plannedSwipe.points.length >= 2) {
        ctx.save();
        ctx.beginPath();
        const startPt = plannedSwipe.points[0];
        ctx.moveTo(startPt.x * width, startPt.y * height);

        for (let i = 1; i < plannedSwipe.points.length; i++) {
          const pt = plannedSwipe.points[i];
          ctx.lineTo(pt.x * width, pt.y * height);
        }

        ctx.strokeStyle = '#ff5e00';
        ctx.lineWidth = 4;
        ctx.shadowColor = '#ff8c00';
        ctx.shadowBlur = 15;
        ctx.stroke();

        // Glowing core
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();

        // Waypoints
        for (const pt of plannedSwipe.points) {
          ctx.beginPath();
          ctx.arc(pt.x * width, pt.y * height, 4, 0, Math.PI * 2);
          ctx.fillStyle = '#ff9100';
          ctx.fill();
        }
      }
    };

    animationFrameId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [
    isPaused,
    activeItems,
    settings,
    botState,
    isScreenSharing,
    onSliceFruit,
    onAvoidBomb,
    onRecordGesture,
    spawnItem,
  ]);

  return (
    <div id="vision-radar-view" className="space-y-6">
      {/* Top Header & Screen Sharing Bar */}
      <div className="ninja-panel rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-orange-500/20 text-orange-400">
            <Eye className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              Computer Vision & Screen Capture Radar
            </h3>
            <p className="text-xs text-zinc-400 font-mono">
              Analyzing frame buffers, HSV color contours, and bomb safety corridors at {fps} FPS
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isScreenSharing ? (
            <button
              onClick={handleStartScreenShare}
              className="py-1.5 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-mono text-cyan-300 border border-cyan-500/30 flex items-center gap-1.5 transition-colors"
            >
              <Tv className="w-3.5 h-3.5" />
              Capture Real Screen / Video
            </button>
          ) : (
            <button
              onClick={handleStopScreenShare}
              className="py-1.5 px-3 rounded-lg bg-rose-900/80 hover:bg-rose-800 text-xs font-mono text-rose-200 border border-rose-500/40 flex items-center gap-1.5 transition-colors"
            >
              Stop Screen Capture
            </button>
          )}

          <button
            onClick={() => setIsPaused(!isPaused)}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
            title={isPaused ? 'Resume' : 'Pause frame'}
          >
            {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4" />}
          </button>

          <button
            onClick={() => {
              setActiveItems([]);
              setLastPlannedSwipe(null);
            }}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
            title="Clear all active targets"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Canvas & Side Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Visual Radar Screen */}
        <div className="lg:col-span-3 ninja-panel rounded-2xl p-4 flex flex-col items-center justify-center border-zinc-800 relative overflow-hidden">
          <div className="w-full aspect-[16/9] max-h-[520px] rounded-xl overflow-hidden relative bg-black shadow-inner border border-zinc-800">
            <canvas
              ref={canvasRef}
              width={960}
              height={540}
              className="w-full h-full object-contain cursor-crosshair"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = (e.clientX - rect.left) / rect.width;
                const clickY = (e.clientY - rect.top) / rect.height;
                spawnItem('fruit', undefined, { x: clickX, y: clickY });
              }}
            />

            {/* Hidden video element for screen share */}
            <video ref={videoRef} className="hidden" playsInline muted autoPlay />

            {/* Overlaid HUD status pills */}
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <div className="px-2 py-1 rounded bg-black/70 border border-zinc-800 text-[11px] font-mono text-emerald-400 backdrop-blur-sm">
                FPS: {fps}
              </div>
              <div className="px-2 py-1 rounded bg-black/70 border border-zinc-800 text-[11px] font-mono text-orange-400 backdrop-blur-sm">
                FRUITS: {activeItems.filter((i) => i.type === 'fruit' && !i.isSliced).length}
              </div>
              <div className="px-2 py-1 rounded bg-black/70 border border-zinc-800 text-[11px] font-mono text-rose-400 backdrop-blur-sm">
                BOMBS: {activeItems.filter((i) => i.type === 'bomb').length}
              </div>
            </div>

            {/* Bottom prompt */}
            <div className="absolute bottom-2 right-3 text-[10px] font-mono text-zinc-500 bg-black/60 px-2 py-0.5 rounded pointer-events-none">
              Click radar to spawn fruit at coordinates
            </div>
          </div>
        </div>

        {/* Radar Controls & Spawner */}
        <div className="ninja-panel rounded-2xl p-5 flex flex-col justify-between border-zinc-800 space-y-4">
          <div>
            <h4 className="text-xs font-bold text-zinc-300 font-mono uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-orange-400" />
              Target Spawner & Test Waves
            </h4>

            <div className="grid grid-cols-2 gap-2 mb-4">
              <button
                onClick={() => spawnItem('fruit', 'Watermelon')}
                className="py-2 px-2.5 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center justify-between transition-colors"
              >
                <span>Watermelon</span>
                <Plus className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => spawnItem('fruit', 'Banana')}
                className="py-2 px-2.5 rounded-lg bg-amber-950/40 hover:bg-amber-900/60 border border-amber-500/30 text-amber-300 text-xs font-mono flex items-center justify-between transition-colors"
              >
                <span>Banana</span>
                <Plus className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => spawnItem('fruit', 'Red Apple')}
                className="py-2 px-2.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 text-xs font-mono flex items-center justify-between transition-colors"
              >
                <span>Red Apple</span>
                <Plus className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => spawnItem('bomb')}
                className="py-2 px-2.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 border border-rose-500/50 text-rose-300 text-xs font-mono flex items-center justify-between transition-colors"
              >
                <span className="flex items-center gap-1 font-bold">
                  <Bomb className="w-3.5 h-3.5" /> Bomb
                </span>
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={() => spawnWave(true)}
              className="w-full py-2.5 px-3 rounded-lg bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all mb-4"
            >
              <Zap className="w-4 h-4" />
              Launch High-Risk Wave
            </button>

            {/* Planned trajectory details */}
            <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2">
              <div className="text-[11px] font-mono font-bold text-zinc-400 flex items-center justify-between">
                <span>SWIPE PLANNER:</span>
                <span
                  className={
                    lastPlannedSwipe ? 'text-emerald-400' : 'text-zinc-500'
                  }
                >
                  {lastPlannedSwipe ? 'PATH COMPUTED' : 'AWAITING TARGETS'}
                </span>
              </div>

              {lastPlannedSwipe && (
                <div className="space-y-1 text-[11px] font-mono text-zinc-300">
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Target Fruits:</span>
                    <span>{lastPlannedSwipe.targetFruitIds.length} targets</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Safety Score:</span>
                    <span className="text-emerald-400 font-bold">{lastPlannedSwipe.safetyScore}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Duration:</span>
                    <span>{lastPlannedSwipe.durationMs} ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Bomb Corridor:</span>
                    <span className="text-emerald-400">CLEAR (Avoids {lastPlannedSwipe.avoidsBombIds.length})</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="text-[11px] text-zinc-500 font-mono border-t border-zinc-800/80 pt-3">
            Priority rule: Bomb avoidance strictly overrides multi-fruit combos.
          </div>
        </div>
      </div>
    </div>
  );
};
