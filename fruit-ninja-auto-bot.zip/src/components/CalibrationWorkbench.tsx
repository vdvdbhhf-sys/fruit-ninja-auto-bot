import React, { useState } from 'react';
import {
  Sliders,
  Cpu,
  Upload,
  CheckCircle2,
  AlertCircle,
  Play,
  RotateCcw,
  SkipForward,
  X,
  Sparkles,
  MousePointerClick,
  Layers,
} from 'lucide-react';
import { BotSettings, AccessibleButtonCandidate } from '../types';
import { computerVisionService } from '../services/ComputerVisionService';
import { ninjaAudio } from '../services/AudioService';

interface CalibrationWorkbenchProps {
  settings: BotSettings;
  onUpdateSettings: (newSettings: Partial<BotSettings>) => void;
  onSimulateButtonClick: (btn: AccessibleButtonCandidate) => void;
}

export const CalibrationWorkbench: React.FC<CalibrationWorkbenchProps> = ({
  settings,
  onUpdateSettings,
  onSimulateButtonClick,
}) => {
  const [modelFile, setModelFile] = useState<string | null>(null);
  const [modelStatus, setModelStatus] = useState<'default' | 'uploaded'>('default');
  const [activeScreenSim, setActiveScreenSim] = useState<'gameplay' | 'result' | 'interstitial_ad'>('result');
  const [lastClickedName, setLastClickedName] = useState<string | null>(null);

  // Simulated accessibility nodes for testing
  const dummyScreens = {
    result: [
      { id: 'btn_replay', text: 'Replay', clickable: true, type: 'replay' as const, bounds: { x: 0.35, y: 0.75, width: 0.3, height: 0.08 }, confidence: 0.98 },
      { id: 'btn_continue', text: 'Continue', clickable: true, type: 'continue' as const, bounds: { x: 0.7, y: 0.75, width: 0.25, height: 0.08 }, confidence: 0.94 },
      { id: 'btn_leaderboard', text: 'Leaderboard', clickable: true, type: 'other' as const, bounds: { x: 0.05, y: 0.75, width: 0.25, height: 0.08 }, confidence: 0.4 },
    ],
    interstitial_ad: [
      { id: 'btn_skip_ad', text: 'Skip in 5s', clickable: true, type: 'skip' as const, bounds: { x: 0.82, y: 0.05, width: 0.15, height: 0.06 }, confidence: 0.95 },
      { id: 'btn_close_x', text: 'X', clickable: true, type: 'close' as const, bounds: { x: 0.92, y: 0.05, width: 0.06, height: 0.06 }, confidence: 0.99 },
      { id: 'btn_install_ad', text: 'INSTALL NOW', clickable: true, type: 'other' as const, bounds: { x: 0.25, y: 0.85, width: 0.5, height: 0.09 }, confidence: 0.2 },
    ],
    gameplay: [
      { id: 'btn_pause', text: 'Pause', clickable: true, type: 'other' as const, bounds: { x: 0.05, y: 0.05, width: 0.1, height: 0.06 }, confidence: 0.5 },
    ],
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (reader.result instanceof ArrayBuffer) {
        computerVisionService.loadCustomTFLiteModel(file.name, reader.result);
        setModelFile(file.name);
        setModelStatus('uploaded');
        ninjaAudio.playButtonClick();
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const cvStats = computerVisionService.getStats();

  return (
    <div id="calibration-workbench" className="space-y-6">
      {/* Top Header */}
      <div className="ninja-panel rounded-2xl p-4 flex items-center justify-between border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-orange-500/20 text-orange-400">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              Computer Vision & Node Matcher Workbench
            </h3>
            <p className="text-xs text-zinc-400 font-mono">
              Calibrate HSV segmentation, inspect TFLite neural models, and test AccessibilityNodeInfo clicks
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Module 1: Computer Vision Engine & TFLite Slot */}
        <div className="ninja-panel rounded-2xl p-6 border-zinc-800 space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-cyan-400" />
                <h4 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                  Detection Engine Architecture
                </h4>
              </div>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-cyan-950/40 text-cyan-300 border border-cyan-800">
                {settings.detectionEngine}
              </span>
            </div>

            <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-3 mb-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Active Engine:</span>
                <span className="text-zinc-200 font-semibold">{cvStats.modelName}</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Avg Inference Latency:</span>
                <span className="text-emerald-400 font-bold">{cvStats.avgInferenceTimeMs} ms</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Detectable Fruit/Bomb Classes:</span>
                <span className="text-amber-400 font-bold">{cvStats.classesCount} Classes</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Model Status:</span>
                <span className="text-emerald-400 flex items-center gap-1 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> READY
                </span>
              </div>
            </div>

            {/* Custom TFLite Model Upload */}
            <div className="p-4 rounded-xl bg-zinc-900/60 border border-dashed border-zinc-700 hover:border-orange-500/50 transition-colors text-center">
              <Upload className="w-6 h-6 text-orange-400 mx-auto mb-2" />
              <h5 className="text-xs font-bold text-zinc-200 font-mono mb-1">
                {modelFile ? `Active: ${modelFile}` : 'Slot: Custom TensorFlow Lite Model (.tflite)'}
              </h5>
              <p className="text-[11px] text-zinc-500 font-mono mb-3">
                Drop your YOLOv8-FruitNinja or MobileNet-SSD .tflite weights to override the default HSV contour pipeline.
              </p>
              <label className="inline-flex items-center gap-2 py-1.5 px-4 rounded-lg bg-orange-600 hover:bg-orange-500 text-black font-mono text-xs font-bold cursor-pointer transition-colors">
                <span>Browse .tflite File</span>
                <input
                  type="file"
                  accept=".tflite,.bin,.json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Threshold Sliders */}
          <div className="space-y-4 pt-4 border-t border-zinc-800/80">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Fruit Confidence Threshold:</span>
                <span className="text-orange-400 font-bold">
                  {Math.round(settings.fruitConfidenceThreshold * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.3"
                max="0.95"
                step="0.05"
                value={settings.fruitConfidenceThreshold}
                onChange={(e) =>
                  onUpdateSettings({ fruitConfidenceThreshold: parseFloat(e.target.value) })
                }
                className="w-full accent-orange-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Bomb Confidence Threshold:</span>
                <span className="text-rose-400 font-bold">
                  {Math.round(settings.bombConfidenceThreshold * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.4"
                max="0.95"
                step="0.05"
                value={settings.bombConfidenceThreshold}
                onChange={(e) =>
                  onUpdateSettings({ bombConfidenceThreshold: parseFloat(e.target.value) })
                }
                className="w-full accent-rose-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-zinc-400">Bomb Clearance Safe Radius:</span>
                <span className="text-amber-400 font-bold">
                  {Math.round(settings.bombSafetyRadius * 100)}% screen
                </span>
              </div>
              <input
                type="range"
                min="0.08"
                max="0.30"
                step="0.02"
                value={settings.bombSafetyRadius}
                onChange={(e) =>
                  onUpdateSettings({ bombSafetyRadius: parseFloat(e.target.value) })
                }
                className="w-full accent-amber-500 bg-zinc-800 rounded-lg h-1.5 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Module 2: AccessibilityNodeInfo Button Matcher & Ad Tester */}
        <div className="ninja-panel rounded-2xl p-6 border-zinc-800 space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <MousePointerClick className="w-5 h-5 text-emerald-400" />
                <h4 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                  Accessibility Node Matcher Tester
                </h4>
              </div>
              <span className="text-xs text-zinc-400 font-mono">Simulated Window Hierarchy</span>
            </div>

            {/* Screen Selector Tabs */}
            <div className="flex gap-2 mb-4 bg-zinc-900 p-1 rounded-xl border border-zinc-800">
              {(['result', 'interstitial_ad', 'gameplay'] as const).map((scr) => (
                <button
                  key={scr}
                  onClick={() => {
                    ninjaAudio.playButtonClick();
                    setActiveScreenSim(scr);
                  }}
                  className={`flex-1 py-1.5 text-xs font-mono uppercase rounded-lg transition-all ${
                    activeScreenSim === scr
                      ? 'bg-orange-600 text-black font-bold shadow'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {scr.replace('_', ' ')}
                </button>
              ))}
            </div>

            {/* Visual Node Canvas Preview */}
            <div className="w-full aspect-[16/9] rounded-xl bg-zinc-950 border border-zinc-800 relative p-4 flex flex-col justify-between overflow-hidden shadow-inner">
              <div className="flex justify-between items-center text-[10px] font-mono text-zinc-500">
                <span>com.halfbrick.fruitninja</span>
                <span>STATE: {activeScreenSim.toUpperCase()}</span>
              </div>

              {/* Centered screen mock text */}
              <div className="text-center">
                {activeScreenSim === 'result' && (
                  <div>
                    <h5 className="font-ninja text-3xl text-orange-400 font-bold">GAME OVER</h5>
                    <p className="text-xs text-zinc-400 font-mono">Score: 420 • Combo: 8x</p>
                  </div>
                )}
                {activeScreenSim === 'interstitial_ad' && (
                  <div>
                    <h5 className="font-mono text-xl text-purple-400 font-bold">SPONSORED VIDEO</h5>
                    <p className="text-xs text-zinc-500 font-mono">Advertisement playing (15s)</p>
                  </div>
                )}
                {activeScreenSim === 'gameplay' && (
                  <div>
                    <p className="text-xs text-zinc-400 font-mono">Active Arcade Dojo Gameplay</p>
                  </div>
                )}
              </div>

              {/* Detected Candidate Nodes */}
              <div className="flex flex-wrap gap-2 justify-center">
                {dummyScreens[activeScreenSim].map((btn) => (
                  <button
                    key={btn.id}
                    onClick={() => {
                      ninjaAudio.playButtonClick();
                      setLastClickedName(btn.text);
                      onSimulateButtonClick(btn);
                    }}
                    className={`py-2 px-4 rounded-lg font-mono text-xs font-bold transition-transform active:scale-95 flex items-center gap-1.5 shadow-md ${
                      btn.type === 'replay' || btn.type === 'continue' || btn.type === 'play'
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-400 blade-glow'
                        : btn.type === 'skip' || btn.type === 'close'
                        ? 'bg-purple-600 hover:bg-purple-500 text-white border border-purple-400'
                        : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700'
                    }`}
                  >
                    {btn.type === 'replay' && <RotateCcw className="w-3.5 h-3.5" />}
                    {btn.type === 'skip' && <SkipForward className="w-3.5 h-3.5" />}
                    {btn.type === 'close' && <X className="w-3.5 h-3.5" />}
                    <span>{btn.text}</span>
                    <span className="text-[9px] opacity-75 font-normal">({Math.round(btn.confidence * 100)}%)</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Heuristic Click Status Log */}
          <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs font-mono space-y-1">
            <div className="text-zinc-400 flex items-between justify-between">
              <span>Node Click Dispatcher:</span>
              <span className={lastClickedName ? 'text-emerald-400 font-bold' : 'text-zinc-500'}>
                {lastClickedName ? `ACTION_CLICK -> "${lastClickedName}"` : 'READY'}
              </span>
            </div>
            <p className="text-[11px] text-zinc-500">
              When matched, invokes <code className="text-orange-300">AccessibilityNodeInfo.performAction(ACTION_CLICK)</code>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
