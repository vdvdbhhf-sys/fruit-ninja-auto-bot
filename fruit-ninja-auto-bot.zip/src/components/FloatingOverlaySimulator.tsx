import React, { useState } from 'react';
import {
  GripHorizontal,
  Play,
  Square,
  ShieldAlert,
  Flame,
  Award,
  Layers,
  ChevronDown,
  ChevronUp,
  Smartphone,
} from 'lucide-react';
import { BotState, BotMetrics } from '../types';
import { ninjaAudio } from '../services/AudioService';

interface FloatingOverlaySimulatorProps {
  botState: BotState;
  metrics: BotMetrics;
  onToggleBot: () => void;
  onEmergencyStop: () => void;
}

export const FloatingOverlaySimulator: React.FC<FloatingOverlaySimulatorProps> = ({
  botState,
  metrics,
  onToggleBot,
  onEmergencyStop,
}) => {
  const [pos, setPos] = useState({ x: 30, y: 50 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isExpanded, setIsExpanded] = useState(true);

  const isRunning = botState !== 'IDLE' && botState !== 'STOPPED' && botState !== 'ERROR';

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - pos.x,
      y: e.clientY - pos.y,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPos({
      x: Math.max(10, Math.min(window.innerWidth - 300, e.clientX - dragOffset.x)),
      y: Math.max(10, Math.min(window.innerHeight - 200, e.clientY - dragOffset.y)),
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div
      id="floating-overlay-simulator-view"
      className="space-y-6"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* Top Header */}
      <div className="ninja-panel rounded-2xl p-4 flex items-center justify-between border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              Android WindowManager Floating Overlay
            </h3>
            <p className="text-xs text-zinc-400 font-mono">
              Draggable HUD running on top of Fruit Ninja (<code className="text-cyan-300">TYPE_APPLICATION_OVERLAY</code>)
            </p>
          </div>
        </div>
      </div>

      {/* Phone Stage Mockup */}
      <div className="ninja-panel rounded-2xl p-6 border-zinc-800 flex flex-col items-center">
        <div className="max-w-md w-full aspect-[9/18] max-h-[640px] rounded-[36px] bg-zinc-950 border-[6px] border-zinc-800 relative overflow-hidden shadow-2xl p-4 flex flex-col justify-between select-none">
          {/* Phone Speaker Notch */}
          <div className="w-28 h-4 bg-zinc-800 rounded-full mx-auto mb-2 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-zinc-900 mr-2"></div>
            <div className="w-10 h-1.5 rounded-full bg-zinc-900"></div>
          </div>

          {/* Fruit Ninja Game Simulation Background */}
          <div className="absolute inset-0 top-6 bottom-6 bg-gradient-to-b from-[#1c1815] via-[#120f0d] to-[#0c0908] flex flex-col items-center justify-center p-6 text-center opacity-80 pointer-events-none">
            <div className="font-ninja text-4xl font-extrabold text-orange-500 tracking-wider mb-2">
              FRUIT NINJA
            </div>
            <p className="text-xs font-mono text-zinc-500 max-w-xs">
              Live Game Window (<code className="text-zinc-400">com.halfbrick.fruitninja</code>)
            </p>
            <div className="mt-8 px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-mono">
              Active Dojo Canvas
            </div>
          </div>

          {/* Interactive Floating HUD Widget */}
          <div
            id="draggable-floating-overlay-widget"
            style={{
              transform: `translate(${pos.x * 0.4}px, ${pos.y * 0.4}px)`,
              transition: isDragging ? 'none' : 'transform 0.05s ease-out',
            }}
            className="z-30 w-64 rounded-xl bg-zinc-900/95 border border-orange-500/40 shadow-2xl backdrop-blur-md overflow-hidden blade-glow cursor-grab active:cursor-grabbing"
          >
            {/* Drag Handle & Title Bar */}
            <div
              onMouseDown={handleMouseDown}
              className="px-3 py-2 bg-gradient-to-r from-[#ff5e00]/30 to-[#ff9100]/20 border-b border-zinc-800 flex items-center justify-between text-xs font-mono text-zinc-200"
            >
              <div className="flex items-center gap-1.5">
                <GripHorizontal className="w-4 h-4 text-orange-400" />
                <span className="font-bold text-orange-300">NINJA BOT HUD</span>
              </div>
              <div className="flex items-center gap-1">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                  }`}
                />
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsExpanded(!isExpanded);
                  }}
                  className="text-zinc-400 hover:text-zinc-200 p-0.5"
                >
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Content Body */}
            {isExpanded && (
              <div className="p-3 space-y-2.5">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-zinc-400">STATE:</span>
                  <span className="font-bold text-orange-400">{botState}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                  <div className="p-1.5 rounded-lg bg-zinc-950/80 border border-zinc-800">
                    <div className="text-[10px] text-zinc-500 flex items-center justify-center gap-1">
                      <Award className="w-3 h-3 text-orange-400" /> Games
                    </div>
                    <div className="font-bold text-white text-sm">{metrics.gamesPlayed}</div>
                  </div>

                  <div className="p-1.5 rounded-lg bg-zinc-950/80 border border-zinc-800">
                    <div className="text-[10px] text-zinc-500 flex items-center justify-center gap-1">
                      <Flame className="w-3 h-3 text-emerald-400" /> Sliced
                    </div>
                    <div className="font-bold text-emerald-400 text-sm">{metrics.fruitsSliced}</div>
                  </div>
                </div>

                {/* Overlay Action Buttons */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => {
                      ninjaAudio.playButtonClick();
                      onToggleBot();
                    }}
                    className={`py-1.5 px-2 rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-1 transition-all ${
                      isRunning
                        ? 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700'
                        : 'bg-orange-600 hover:bg-orange-500 text-black shadow-md'
                    }`}
                  >
                    {isRunning ? (
                      <>
                        <Square className="w-3 h-3 fill-current" /> Stop
                      </>
                    ) : (
                      <>
                        <Play className="w-3 h-3 fill-current" /> Start
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => {
                      ninjaAudio.playEmergencyStop();
                      onEmergencyStop();
                    }}
                    className="py-1.5 px-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-mono text-xs font-bold flex items-center justify-center gap-1 border border-rose-400 transition-all blade-glow-danger"
                  >
                    <ShieldAlert className="w-3 h-3" /> EMG
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Home Indicator */}
          <div className="w-32 h-1 bg-zinc-700 rounded-full mx-auto mt-2"></div>
        </div>
      </div>
    </div>
  );
};
