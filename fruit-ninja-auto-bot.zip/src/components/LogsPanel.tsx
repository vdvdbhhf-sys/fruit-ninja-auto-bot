import React, { useState } from 'react';
import { Terminal, Trash2, Filter, Download, ArrowDown } from 'lucide-react';
import { LogEntry } from '../types';
import { ninjaAudio } from '../services/AudioService';

interface LogsPanelProps {
  logs: LogEntry[];
  onClearLogs: () => void;
}

export const LogsPanel: React.FC<LogsPanelProps> = ({ logs, onClearLogs }) => {
  const [filter, setFilter] = useState<'all' | 'gesture' | 'vision' | 'ad' | 'error'>('all');

  const filteredLogs = logs.filter((log) => {
    if (filter === 'all') return true;
    return log.level === filter;
  });

  const getLevelBadge = (level: LogEntry['level']) => {
    switch (level) {
      case 'gesture':
        return 'text-orange-400 bg-orange-500/10 border-orange-500/30';
      case 'vision':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'ad':
        return 'text-purple-400 bg-purple-500/10 border-purple-500/30';
      case 'error':
        return 'text-rose-400 bg-rose-500/10 border-rose-500/30 font-bold';
      case 'warn':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      default:
        return 'text-zinc-400 bg-zinc-800 border-zinc-700';
    }
  };

  const handleExportLogs = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `FruitNinja_AutoBot_Logs_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div id="logs-panel" className="space-y-6">
      {/* Header & Controls */}
      <div className="ninja-panel rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-orange-500/20 text-orange-400">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              Real-time Subsystem Event Log
            </h3>
            <p className="text-xs text-zinc-400 font-mono">
              Accessibility events, gesture dispatches, CV detections, and state machine transitions
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Filter Pills */}
          <div className="flex rounded-lg bg-zinc-900 p-1 border border-zinc-800 text-xs font-mono">
            {(['all', 'gesture', 'vision', 'ad', 'error'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  ninjaAudio.playButtonClick();
                  setFilter(lvl);
                }}
                className={`px-2.5 py-1 uppercase rounded transition-all ${
                  filter === lvl
                    ? 'bg-orange-600 text-white font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportLogs}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
            title="Download Logs as JSON"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              ninjaAudio.playButtonClick();
              onClearLogs();
            }}
            className="p-1.5 rounded-lg bg-zinc-800 hover:bg-rose-900/60 text-zinc-300 hover:text-rose-300 transition-colors"
            title="Clear all logs"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Log Console Container */}
      <div className="ninja-panel rounded-2xl p-4 border-zinc-800">
        <div className="rounded-xl bg-zinc-950 p-4 border border-zinc-800 min-h-[440px] max-h-[560px] overflow-y-auto space-y-2 font-mono text-xs">
          {filteredLogs.length === 0 ? (
            <div className="text-zinc-600 text-center py-20">No matching log entries found</div>
          ) : (
            filteredLogs.map((log) => {
              const timeStr = new Date(log.timestamp).toLocaleTimeString();
              return (
                <div
                  key={log.id}
                  className="flex items-start gap-2.5 p-2 rounded-lg bg-zinc-900/40 hover:bg-zinc-900/90 transition-colors border border-transparent hover:border-zinc-800"
                >
                  <span className="text-[11px] text-zinc-500 whitespace-nowrap">{timeStr}</span>
                  <span
                    className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded border whitespace-nowrap ${getLevelBadge(
                      log.level
                    )}`}
                  >
                    {log.level}
                  </span>
                  <div className="flex-1 text-zinc-300">
                    <div>{log.message}</div>
                    {log.details && (
                      <pre className="text-[10px] text-zinc-500 mt-1 bg-black/40 p-1.5 rounded overflow-x-auto">
                        {JSON.stringify(log.details, null, 2)}
                      </pre>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
